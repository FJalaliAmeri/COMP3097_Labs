//
//  ViewController.swift
//  Lab4_101303158
//
//  Created by Tech on 2023-02-03.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func getBackToMain(_ segue: UIStoryboardSegue){
        print(segue.identifier)
    }
    
}

