//
//  BlackViewController.swift
//  Lab4_101303158
//
//  Created by Tech on 2023-02-03.
//

import UIKit

class BlackViewController: UIViewController {
    
    
    @IBOutlet weak var messageBox: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func getBack(_ segue: UIStoryboardSegue){
        
    }
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "red" {
            let c = segue.destination as! RedViewController
            if let s = messageBox.text {
                c.message = s
            }
           
        }
    }
    

}
