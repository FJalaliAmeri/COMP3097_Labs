//
//  ViewController.swift
//  101303158_Lab03
//
//  Created by Tech on 2023-01-26.
//

import UIKit

class ViewController: UIViewController {
    var counter =  0
    var step = 1
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var stepUpBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        label.text = "\(counter)"
        stepUpBtn.setTitle("StepUp (\(step))", for: .normal)
        
    }

    @IBAction func addOne(_ sender: UIButton) {
        counter += step
        label.text = "\(counter)"
    }
    
    @IBAction func minus1(_ sender: UIButton) {
        counter -= step
        label.text = "\(counter)"
    }
    
    @IBAction func clear(_ sender: UIButton) {
        counter = 0
        step = 1
        label.text = "\(counter)"
        stepUpBtn.setTitle("StepUp (\(step))", for: .normal)
        
    }
    
    @IBAction func stepUp(_ sender: UIButton) {
        step += 1
        sender.setTitle("StepUp (\(step))", for: .normal)
    }
    
    

}

