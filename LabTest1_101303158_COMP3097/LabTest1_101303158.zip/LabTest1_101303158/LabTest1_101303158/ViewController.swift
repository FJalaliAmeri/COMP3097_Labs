//
//  ViewController.swift
//  LabTest1_101303158
// Farshad Jalali Ameri
//
//  Created by Tech on 2023-02-16.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var N1: UILabel!
    @IBOutlet weak var N2: UILabel!
    @IBOutlet weak var N3: UILabel!
    @IBOutlet weak var N4: UILabel!
    @IBOutlet weak var N5: UILabel!
    @IBOutlet weak var N6: UILabel!
    var randNums: [Int] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func randomInt(max: Int) -> Int {
     let rand: Int = Int(arc4random())
     return (rand % max) + 1
     }
    
     func randomNum() -> Int {
     let max: Int = 65
     let random = randomInt(max: max)
     return random
     }
    
    @IBAction func draw(_ sender: Any) {
        var i = 0
        while (i <= 5){
            var currNum = randomNum()
            if (randNums.contains(currNum)){
                currNum = randomNum()
            } else {
            randNums.append(currNum)
            i += 1
            }
        }
    
        N1.text = String(randNums[0])
        N2.text = String(randNums[1])
        N3.text = String(randNums[2])
        N4.text = String(randNums[3])
        N5.text = String(randNums[4])
        N6.text = String(randNums[5])
        
        print(randNums)
        randNums.removeAll()
        
    }
    @IBAction func clear(_ sender: Any) {
        N1.text = "-"
        N2.text = "-"
        N3.text = "-"
        N4.text = "-"
        N5.text = "-"
        N6.text = "-"
        
    }
}

