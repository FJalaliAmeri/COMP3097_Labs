//
//  ViewController.swift
//  lab5_101303158
//
//  Created by Tech on 2023-02-09.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var labelCode: UILabel!
    
    var country:Country! = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = country.name
        labelCode.text =  country.code
        
    }


}

